# Standalone Indoor Fingerprint Collector

Android-only Wi-Fi RSSI fingerprint collector and KNN indoor position estimator.

## Features
- Nearby AP RSSI scan and upward bar chart
- Reference point X/Y in feet
- Repeated scan capture and averaged RSSI per BSSID
- SQLite fingerprint database
- KNN position estimation with configurable K (default 4)
- CSV export
- No ESP32 required

## CSI limitation
Normal stock Android applications do not receive raw OFDM CSI through the public Android Wi-Fi API. The app explicitly shows this limitation and does not generate fake CSI values. Real CSI requires a compatible rooted/modified Wi-Fi stack (for example, device-specific Nexmon support).

## Build
`gradle :app:assembleDebug`
