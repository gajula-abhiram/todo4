package com.abhiram.indoorposition;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int REQ_PERMISSIONS = 41;
    private static final int MAX_GRAPH_APS = 8;
    private static final int DEFAULT_K = 4;
    private static final int MISSING_RSSI = -100;

    private WifiManager wifiManager;
    private FingerprintDb db;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView statusText;
    private TextView captureText;
    private TextView estimateText;
    private EditText xInput;
    private EditText yInput;
    private EditText kInput;
    private RssiBarChart chart;

    private List<ScanResult> latestResults = new ArrayList<>();
    private final Map<String, Accumulator> capture = new HashMap<>();
    private boolean capturing = false;
    private int scanEvents = 0;

    private final Runnable captureLoop = new Runnable() {
        @Override public void run() {
            if (!capturing) return;
            requestScan(false);
            handler.postDelayed(this, 3500);
        }
    };

    private final BroadcastReceiver scanReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            readScanResults();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        db = new FingerprintDb(this);
        buildUi();
        registerReceiver(scanReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        updatePermissionStatus();
        if (hasRequiredPermissions()) requestScan(false);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try { unregisterReceiver(scanReceiver); } catch (Exception ignored) {}
        db.close();
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView rootScroll = new ScrollView(this);
        rootScroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(Color.rgb(247, 249, 252));
        rootScroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Indoor Position Fingerprint Collector", 26, true, Color.rgb(18, 50, 84));
        root.addView(title);
        TextView subtitle = text("Standalone Android RSSI fingerprint collection + KNN position estimation", 15, false, Color.DKGRAY);
        subtitle.setPadding(0, dp(3), 0, dp(12));
        root.addView(subtitle);

        statusText = cardText("Permission status", 15);
        root.addView(statusText);
        Button permissionBtn = button("Grant Wi-Fi / Location Permission");
        permissionBtn.setOnClickListener(v -> requestPermissionsIfNeeded());
        root.addView(permissionBtn);

        TextView warning = cardText(
                "CSI hardware note\nStock Android does not expose raw OFDM Channel State Information (CSI) to normal apps. " +
                "This APK does not fabricate CSI. Real CSI needs a supported rooted phone / chipset with a CSI extraction driver such as Nexmon. " +
                "Everything else in this app works without an ESP32.", 14);
        warning.setTextColor(Color.rgb(125, 67, 0));
        root.addView(warning);

        addSection(root, "Live Wi-Fi RSSI");
        chart = new RssiBarChart(this);
        chart.setMinimumHeight(dp(280));
        root.addView(chart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));

        LinearLayout scanRow = horizontal();
        Button scanBtn = button("Scan Wi-Fi");
        scanBtn.setOnClickListener(v -> requestScan(true));
        scanRow.addView(scanBtn, weight());
        Button settingsBtn = button("Location Settings");
        settingsBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)));
        scanRow.addView(settingsBtn, weight());
        root.addView(scanRow);

        addSection(root, "Reference Point Capture");
        LinearLayout xyRow = horizontal();
        xInput = numberInput("X (feet)");
        yInput = numberInput("Y (feet)");
        xyRow.addView(xInput, weight());
        xyRow.addView(yInput, weight());
        root.addView(xyRow);

        captureText = cardText("No active capture.", 14);
        root.addView(captureText);

        LinearLayout captureRow = horizontal();
        Button startBtn = button("Start Capture");
        Button stopBtn = button("Stop");
        captureRow.addView(startBtn, weight());
        captureRow.addView(stopBtn, weight());
        root.addView(captureRow);
        startBtn.setOnClickListener(v -> startCapture());
        stopBtn.setOnClickListener(v -> stopCapture());

        LinearLayout saveRow = horizontal();
        Button saveBtn = button("Save Reference Point");
        Button clearBtn = button("Clear Capture");
        saveRow.addView(saveBtn, weight());
        saveRow.addView(clearBtn, weight());
        root.addView(saveRow);
        saveBtn.setOnClickListener(v -> saveReferencePoint());
        clearBtn.setOnClickListener(v -> clearCapture());

        addSection(root, "KNN Position Test");
        kInput = numberInput("K (default 4)");
        kInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        kInput.setText(String.valueOf(DEFAULT_K));
        root.addView(kInput);
        Button estimateBtn = button("Estimate Current Position");
        estimateBtn.setOnClickListener(v -> estimatePosition());
        root.addView(estimateBtn);
        estimateText = cardText("Save several reference points first, then scan at an unknown position.", 14);
        root.addView(estimateText);

        addSection(root, "Database & Export");
        LinearLayout dbRow = horizontal();
        Button viewBtn = button("View Saved Points");
        viewBtn.setOnClickListener(v -> showSavedPoints());
        dbRow.addView(viewBtn, weight());
        Button exportBtn = button("Export CSV");
        exportBtn.setOnClickListener(v -> exportCsv());
        dbRow.addView(exportBtn, weight());
        root.addView(dbRow);

        TextView footer = text(
                "How to collect: stand at a known point → enter X,Y in feet → Start Capture → wait for several scan events → Stop → Save Reference Point. " +
                "For testing, move to an unknown point, tap Scan Wi-Fi, then Estimate Current Position.",
                13, false, Color.DKGRAY);
        footer.setPadding(0, dp(18), 0, dp(8));
        root.addView(footer);

        setContentView(rootScroll);
    }

    private void addSection(LinearLayout root, String s) {
        TextView t = text(s, 19, true, Color.rgb(18, 50, 84));
        t.setPadding(0, dp(20), 0, dp(7));
        root.addView(t);
    }

    private TextView text(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setLineSpacing(0, 1.08f);
        return t;
    }

    private TextView cardText(String s, int sp) {
        TextView t = text(s, sp, false, Color.rgb(30, 30, 30));
        t.setBackgroundColor(Color.WHITE);
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(7), 0, dp(7));
        t.setLayoutParams(lp);
        t.setElevation(dp(1));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(13);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        return lp;
    }

    private EditText numberInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        e.setLayoutParams(lp);
        return e;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private boolean hasRequiredPermissions() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return false;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }

    private void requestPermissionsIfNeeded() {
        List<String> needed = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        }
        if (needed.isEmpty()) {
            updatePermissionStatus();
            requestScan(false);
        } else {
            requestPermissions(needed.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS) {
            updatePermissionStatus();
            if (hasRequiredPermissions()) requestScan(false);
        }
    }

    private void updatePermissionStatus() {
        boolean fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean nearby = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED;
        statusText.setText("Permissions — Fine location: " + (fine ? "granted" : "missing") +
                " | Nearby Wi-Fi: " + (nearby ? "granted" : "missing") +
                "\nWi-Fi: " + (wifiManager != null && wifiManager.isWifiEnabled() ? "ON" : "OFF") +
                " | Location services must also be ON for scan results.");
    }

    private void requestScan(boolean notify) {
        if (!hasRequiredPermissions()) {
            if (notify) toast("Grant Wi-Fi/location permissions first.");
            return;
        }
        if (wifiManager == null || !wifiManager.isWifiEnabled()) {
            if (notify) toast("Turn Wi-Fi on first.");
            return;
        }
        try {
            boolean started = wifiManager.startScan();
            if (!started) {
                // Scan throttling may reject active requests. Read the platform's most recent scan anyway.
                readScanResults();
                if (notify) toast("Active scan was throttled; using latest available scan results.");
            } else if (notify) {
                toast("Wi-Fi scan requested.");
            }
        } catch (SecurityException e) {
            toast("Permission error: " + e.getMessage());
        }
    }

    private void readScanResults() {
        if (!hasRequiredPermissions()) return;
        try {
            List<ScanResult> results = wifiManager.getScanResults();
            if (results == null) results = new ArrayList<>();
            results = new ArrayList<>(results);
            results.sort((a, b) -> Integer.compare(b.level, a.level));
            latestResults = dedupeByBssid(results);
            chart.setResults(latestResults.subList(0, Math.min(MAX_GRAPH_APS, latestResults.size())));
            scanEvents++;
            if (capturing) addToCapture(latestResults);
            updateLiveStatus();
        } catch (SecurityException e) {
            toast("Cannot read scans: " + e.getMessage());
        }
    }

    private List<ScanResult> dedupeByBssid(List<ScanResult> in) {
        List<ScanResult> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ScanResult r : in) {
            if (r.BSSID == null || seen.contains(r.BSSID)) continue;
            seen.add(r.BSSID);
            out.add(r);
        }
        return out;
    }

    private void updateLiveStatus() {
        String top = latestResults.isEmpty() ? "No AP scan data." :
                "Visible APs: " + latestResults.size() + " | Strongest: " + safeSsid(latestResults.get(0)) + " " + latestResults.get(0).level + " dBm";
        if (capturing) {
            captureText.setText("CAPTURING\n" + top + "\nScan events processed: " + scanEvents + " | Unique BSSIDs captured: " + capture.size());
        } else if (!capture.isEmpty()) {
            captureText.setText("Capture stopped. Unique BSSIDs: " + capture.size() + " | Scan events: " + scanEvents + "\nReady to save using the X,Y coordinates above.");
        } else {
            captureText.setText(top + "\nNo active reference-point capture.");
        }
    }

    private String safeSsid(ScanResult r) {
        String s = r.SSID;
        return (s == null || s.trim().isEmpty()) ? "<hidden>" : s;
    }

    private void startCapture() {
        if (!hasRequiredPermissions()) {
            requestPermissionsIfNeeded();
            return;
        }
        capture.clear();
        scanEvents = 0;
        capturing = true;
        addToCapture(latestResults);
        handler.removeCallbacks(captureLoop);
        handler.post(captureLoop);
        updateLiveStatus();
        toast("Capture started. Keep the phone still at this reference point.");
    }

    private void stopCapture() {
        capturing = false;
        handler.removeCallbacks(captureLoop);
        updateLiveStatus();
        toast("Capture stopped.");
    }

    private void clearCapture() {
        capturing = false;
        handler.removeCallbacks(captureLoop);
        capture.clear();
        scanEvents = 0;
        updateLiveStatus();
    }

    private void addToCapture(List<ScanResult> list) {
        for (ScanResult r : list) {
            if (r.BSSID == null) continue;
            Accumulator a = capture.get(r.BSSID);
            if (a == null) {
                a = new Accumulator();
                a.bssid = r.BSSID;
                a.ssid = safeSsid(r);
                a.frequency = r.frequency;
                capture.put(r.BSSID, a);
            }
            a.sum += r.level;
            a.count++;
            a.last = r.level;
            a.frequency = r.frequency;
            a.ssid = safeSsid(r);
        }
    }

    private Double parse(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim()); }
        catch (Exception ex) { return null; }
    }

    private void saveReferencePoint() {
        Double x = parse(xInput);
        Double y = parse(yInput);
        if (x == null || y == null) {
            toast("Enter valid X and Y coordinates in feet.");
            return;
        }
        Map<String, Accumulator> toSave = capture;
        if (toSave.isEmpty()) {
            if (latestResults.isEmpty()) {
                toast("No Wi-Fi measurements available. Scan or capture first.");
                return;
            }
            toSave = new HashMap<>();
            for (ScanResult r : latestResults) {
                Accumulator a = new Accumulator();
                a.bssid = r.BSSID; a.ssid = safeSsid(r); a.frequency = r.frequency; a.sum = r.level; a.count = 1; a.last = r.level;
                toSave.put(a.bssid, a);
            }
        }
        long id = db.savePoint(x, y, toSave);
        toast("Saved reference point #" + id + " at (" + x + ", " + y + ") ft with " + toSave.size() + " AP fingerprints.");
        clearCapture();
    }

    private Map<String, Double> currentVector() {
        Map<String, Double> m = new HashMap<>();
        for (ScanResult r : latestResults) {
            if (r.BSSID != null) m.put(r.BSSID, (double) r.level);
        }
        return m;
    }

    private void estimatePosition() {
        if (latestResults.isEmpty()) {
            toast("Scan Wi-Fi first at the unknown position.");
            return;
        }
        int k = DEFAULT_K;
        try { k = Math.max(1, Integer.parseInt(kInput.getText().toString().trim())); } catch (Exception ignored) {}
        List<PointFingerprint> points = db.loadPoints();
        if (points.isEmpty()) {
            toast("No reference points saved yet.");
            return;
        }
        Map<String, Double> current = currentVector();
        List<Neighbor> neighbors = new ArrayList<>();
        for (PointFingerprint p : points) {
            double d = fingerprintDistance(current, p.rssi);
            neighbors.add(new Neighbor(p, d));
        }
        neighbors.sort(Comparator.comparingDouble(n -> n.distance));
        int kk = Math.min(k, neighbors.size());
        double x = 0, y = 0;
        StringBuilder details = new StringBuilder();
        for (int i = 0; i < kk; i++) {
            Neighbor n = neighbors.get(i);
            x += n.point.x;
            y += n.point.y;
            details.append("#").append(n.point.id)
                    .append(" (").append(fmt(n.point.x)).append(", ").append(fmt(n.point.y)).append(") ft")
                    .append("  d=").append(String.format(Locale.US, "%.2f", n.distance)).append(" dB\n");
        }
        x /= kk; y /= kk;
        estimateText.setText("Estimated position with K=" + kk + ":\nX = " + fmt(x) + " ft\nY = " + fmt(y) + " ft\n\nNearest reference points:\n" + details);
    }

    private double fingerprintDistance(Map<String, Double> current, Map<String, Double> ref) {
        Set<String> keys = new HashSet<>();
        keys.addAll(current.keySet());
        keys.addAll(ref.keySet());
        if (keys.isEmpty()) return 9999;
        double sum = 0;
        for (String bssid : keys) {
            double a = current.containsKey(bssid) ? current.get(bssid) : MISSING_RSSI;
            double b = ref.containsKey(bssid) ? ref.get(bssid) : MISSING_RSSI;
            double diff = a - b;
            sum += diff * diff;
        }
        return Math.sqrt(sum / keys.size());
    }

    private String fmt(double v) {
        return String.format(Locale.US, "%.2f", v);
    }

    private void showSavedPoints() {
        List<PointFingerprint> points = db.loadPoints();
        if (points.isEmpty()) {
            toast("Database is empty.");
            return;
        }
        StringBuilder s = new StringBuilder();
        for (PointFingerprint p : points) {
            s.append("#").append(p.id).append("   X=").append(fmt(p.x)).append(" ft   Y=").append(fmt(p.y)).append(" ft\n")
                    .append("AP fingerprints: ").append(p.rssi.size()).append("\n\n");
        }
        new AlertDialog.Builder(this)
                .setTitle("Saved Reference Points (" + points.size() + ")")
                .setMessage(s.toString())
                .setPositiveButton("Close", null)
                .setNeutralButton("Delete ALL", (d, w) -> confirmDeleteAll())
                .show();
    }

    private void confirmDeleteAll() {
        new AlertDialog.Builder(this)
                .setTitle("Delete all fingerprints?")
                .setMessage("This permanently clears the local reference-point database.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> {
                    db.clearAll();
                    toast("Database cleared.");
                }).show();
    }

    private void exportCsv() {
        try {
            File dir = new File(getExternalFilesDir(null), "exports");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create export folder");
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File file = new File(dir, "rssi_fingerprints_" + stamp + ".csv");
            db.exportCsv(file);
            new AlertDialog.Builder(this)
                    .setTitle("CSV exported")
                    .setMessage(file.getAbsolutePath() + "\n\nThe CSV contains point ID, X/Y in feet, BSSID, SSID, frequency, average RSSI and sample count.")
                    .setPositiveButton("OK", null)
                    .show();
        } catch (Exception e) {
            toast("Export failed: " + e.getMessage());
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    static class Accumulator {
        String bssid;
        String ssid;
        int frequency;
        double sum;
        int count;
        int last;
        double avg() { return count == 0 ? MISSING_RSSI : sum / count; }
    }

    static class PointFingerprint {
        long id;
        double x;
        double y;
        Map<String, Double> rssi = new HashMap<>();
    }

    static class Neighbor {
        PointFingerprint point;
        double distance;
        Neighbor(PointFingerprint p, double d) { point = p; distance = d; }
    }

    static class FingerprintDb extends SQLiteOpenHelper {
        private static final String NAME = "fingerprints.db";
        FingerprintDb(Context c) { super(c, NAME, null, 1); }

        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE reference_points (id INTEGER PRIMARY KEY AUTOINCREMENT, x_ft REAL NOT NULL, y_ft REAL NOT NULL, created_at INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE rssi_fingerprints (id INTEGER PRIMARY KEY AUTOINCREMENT, point_id INTEGER NOT NULL, bssid TEXT NOT NULL, ssid TEXT, frequency_mhz INTEGER, avg_rssi REAL NOT NULL, sample_count INTEGER NOT NULL, FOREIGN KEY(point_id) REFERENCES reference_points(id) ON DELETE CASCADE)");
            db.execSQL("CREATE INDEX idx_rssi_point ON rssi_fingerprints(point_id)");
            db.execSQL("CREATE INDEX idx_rssi_bssid ON rssi_fingerprints(bssid)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

        long savePoint(double x, double y, Map<String, Accumulator> measurements) {
            SQLiteDatabase d = getWritableDatabase();
            d.beginTransaction();
            try {
                ContentValues p = new ContentValues();
                p.put("x_ft", x); p.put("y_ft", y); p.put("created_at", System.currentTimeMillis());
                long id = d.insertOrThrow("reference_points", null, p);
                for (Accumulator a : measurements.values()) {
                    ContentValues f = new ContentValues();
                    f.put("point_id", id); f.put("bssid", a.bssid); f.put("ssid", a.ssid); f.put("frequency_mhz", a.frequency);
                    f.put("avg_rssi", a.avg()); f.put("sample_count", Math.max(1, a.count));
                    d.insertOrThrow("rssi_fingerprints", null, f);
                }
                d.setTransactionSuccessful();
                return id;
            } finally { d.endTransaction(); }
        }

        List<PointFingerprint> loadPoints() {
            SQLiteDatabase d = getReadableDatabase();
            List<PointFingerprint> out = new ArrayList<>();
            Map<Long, PointFingerprint> byId = new HashMap<>();
            try (Cursor c = d.rawQuery("SELECT id,x_ft,y_ft FROM reference_points ORDER BY id", null)) {
                while (c.moveToNext()) {
                    PointFingerprint p = new PointFingerprint();
                    p.id = c.getLong(0); p.x = c.getDouble(1); p.y = c.getDouble(2);
                    out.add(p); byId.put(p.id, p);
                }
            }
            try (Cursor c = d.rawQuery("SELECT point_id,bssid,avg_rssi FROM rssi_fingerprints", null)) {
                while (c.moveToNext()) {
                    PointFingerprint p = byId.get(c.getLong(0));
                    if (p != null) p.rssi.put(c.getString(1), c.getDouble(2));
                }
            }
            return out;
        }

        void clearAll() {
            SQLiteDatabase d = getWritableDatabase();
            d.delete("rssi_fingerprints", null, null);
            d.delete("reference_points", null, null);
        }

        void exportCsv(File file) throws Exception {
            try (FileWriter w = new FileWriter(file);
                 Cursor c = getReadableDatabase().rawQuery(
                         "SELECT p.id,p.x_ft,p.y_ft,p.created_at,f.bssid,f.ssid,f.frequency_mhz,f.avg_rssi,f.sample_count " +
                                 "FROM reference_points p JOIN rssi_fingerprints f ON p.id=f.point_id ORDER BY p.id,f.avg_rssi DESC", null)) {
                w.write("point_id,x_ft,y_ft,created_at,bssid,ssid,frequency_mhz,avg_rssi_dbm,sample_count\n");
                while (c.moveToNext()) {
                    w.write(c.getLong(0) + "," + c.getDouble(1) + "," + c.getDouble(2) + "," + c.getLong(3) + "," +
                            csv(c.getString(4)) + "," + csv(c.getString(5)) + "," + c.getInt(6) + "," + c.getDouble(7) + "," + c.getInt(8) + "\n");
                }
            }
        }

        private static String csv(String s) {
            if (s == null) return "";
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
    }

    static class RssiBarChart extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<ScanResult> results = new ArrayList<>();

        RssiBarChart(Context c) {
            super(c);
            setBackgroundColor(Color.WHITE);
            setPadding(12, 12, 12, 12);
            setElevation(2);
        }

        void setResults(List<ScanResult> r) {
            results = new ArrayList<>(r);
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            paint.setColor(Color.rgb(232, 236, 241));
            paint.setStrokeWidth(2);
            int left = dpLocal(42), right = w - dpLocal(10), top = dpLocal(24), bottom = h - dpLocal(58);
            canvas.drawLine(left, bottom, right, bottom, paint);
            canvas.drawLine(left, top, left, bottom, paint);

            paint.setTextSize(dpLocal(11));
            paint.setColor(Color.GRAY);
            canvas.drawText("100", dpLocal(5), top + dpLocal(4), paint);
            canvas.drawText("Signal", dpLocal(4), top + dpLocal(20), paint);
            canvas.drawText("0", dpLocal(20), bottom, paint);

            if (results.isEmpty()) {
                paint.setColor(Color.DKGRAY);
                paint.setTextSize(dpLocal(14));
                canvas.drawText("No scan data yet", left + dpLocal(24), (top + bottom) / 2f, paint);
                return;
            }
            float gap = dpLocal(7);
            float usable = right - left - gap * (results.size() + 1);
            float barW = Math.max(dpLocal(22), usable / results.size());
            for (int i = 0; i < results.size(); i++) {
                ScanResult r = results.get(i);
                float quality = Math.max(0, Math.min(100, 2f * (r.level + 100))); // -100 ->0, -50 ->100
                float barH = (bottom - top) * quality / 100f;
                float x1 = left + gap + i * (barW + gap);
                float x2 = x1 + barW;
                float y1 = bottom - barH;
                paint.setColor(Color.rgb(56, 126, 184));
                canvas.drawRoundRect(new RectF(x1, y1, x2, bottom), dpLocal(4), dpLocal(4), paint);

                paint.setColor(Color.rgb(25, 48, 70));
                paint.setTextSize(dpLocal(10));
                String dbm = r.level + " dBm";
                canvas.save();
                canvas.rotate(-55, x1 + barW / 2f, bottom + dpLocal(6));
                canvas.drawText(dbm, x1 - dpLocal(4), bottom + dpLocal(12), paint);
                canvas.restore();

                paint.setTextSize(dpLocal(9));
                String ssid = r.SSID == null || r.SSID.isEmpty() ? "hidden" : r.SSID;
                if (ssid.length() > 8) ssid = ssid.substring(0, 8);
                canvas.drawText(ssid, x1, h - dpLocal(7), paint);
            }
        }

        private int dpLocal(int v) {
            return Math.round(v * getResources().getDisplayMetrics().density);
        }
    }
}
