# No shrinking rules are required for this project.
